from flask import Flask, render_template, request, redirect, url_for, flash, session
from sqlalchemy import create_engine, select, MetaData, Table, and_ , insert
import pandas

app = Flask(__name__)
app.secret_key = 'what the fuck'
dataBase = create_engine('mysql+pymysql://root:@localhost/fikafitnessstudio')
client_df = pandas.DataFrame()



def get_db():
    global dataBase
    if dataBase is None:
        dataBase = create_engine('mysql+pymysql://root:@localhost/fikafitnessstudio')
    return dataBase


def get_user_login_details(username):
    db = get_db()
    query = """select lastLogin from user where username = %s"""

    metadata = MetaData(bind=None)
    table = Table(
        'user',
        metadata,
        autoload=True,
        autoload_with=db
    )

    stmt = select([
        table.columns.lastLogin,
    ]).where(table.columns.username == username)

    connection = db.connect()
    results = connection.execute(stmt).mappings().all()

    print(results)

    print(results[0]['lastLogin'])

    return results[0]['lastLogin']


def check_authentication(username, password):
    db = get_db()

    metadata = MetaData(bind=db)
    table = Table(
        'user',
        metadata,
        autoload=True,
        autoload_with=db
    )

    stmt = select([
        table.columns.username,
        table.columns.password
    ]).where(table.columns.username == username)

    connection = db.connect()
    results = connection.execute(stmt).mappings().all()

    print(results)
    username_db = results[0]['username']
    password_db = results[0]['password']
    if username_db == username and password_db == password:
        return True
    else:
        return False

def get_by_user_id(id):
    db = get_db()

    metadata = MetaData(bind=db)
    table = Table(
        'client',
        metadata,
        autoload=True,
        autoload_with=db
    )

    stmt = select([
        table.columns.id,
        table.columns.name,
        table.columns.contact,
        table.columns.package,
        table.columns.exp,
        table.columns.gender,
        table.columns.status,
        table.columns.email,
    ]).where(table.columns.id == id)

    connection = db.connect()
    results = connection.execute(stmt).mappings().all()

    print(results)
    return results[0] if len(results) > 0 else None

def add_new_member_to_fika(member):
    db = get_db()


    metadata = MetaData(bind=db)
    table = Table(
        'client',
        metadata,
        autoload=True,
        autoload_with=db
    )
    if get_by_user_id(member['id']) is None:
        stmt = insert(table).values(id=member['id'],name=member['name'],package=member['package'],exp=member['exp'],email=member['email'],gender=member['gender'],contact=member['contact'])

        stmt.compile()
        connection = db.connect()
        connection.execute(stmt)
        return True
    else:
        return False

def get_client_details():
    db = get_db()

    metadata = MetaData(bind=db)
    table = Table(
        'client',
        metadata,
        autoload=True,
        autoload_with=db
    )

    stmt = select([
        table.columns.id,
        table.columns.name,
        table.columns.gender,
        table.columns.contact,
        table.columns.exp,
        table.columns.email,
        table.columns.status,
        table.columns.package
    ])

    connection = db.connect()
    results = connection.execute(stmt).mappings().all()

    print(results)

    df  = pandas.DataFrame(results)
    global client_df
    client_df = pandas.DataFrame(results)

    print(df)

    return df

@app.route("/")
def welcome():
    return render_template("fikaWelcomePage.html")


@app.route("/login", methods=['GET', 'POST'])
def user():
    isAuthenticatedUser = check_authentication(request.form['username'], request.form['password'])
    if isAuthenticatedUser:
        flash("Successfully logged In", 'success')
        session['username'] = request.form['username']
        if session['username'] == "pandaXmin":
            return render_template("admin.html")
        return redirect(url_for('login',username=session['username']))
    else:
        flash("Invalid Username or Password !", 'danger')
        return render_template("fikaWelcomePage.html")


@app.route("/login/<username>")
def login(username):
    print("hi hello I'm from login / username")
    last_login = get_user_login_details(username)
    session['last_login'] = last_login
    return render_template("user.html", username=username)


@app.route("/login/upload", methods=['GET', 'POST'])
def upload_members_from_file():
    print("hi hello I'm from upload")
    file = request.files['file']
    file.save(file.filename)
    if 'username' in session and session['username'] ==  'pandaXmin':
        data = pandas.read_excel(file)
        data.columns = [x.lower() for x in data.columns]
        data = data[['id', 'name', 'contact', 'package', 'exp', 'email', 'status', 'gender']]
        print(data)
        data.to_sql('client', con=get_db(), if_exists='append', chunksize=2000, index= False)
        flash("Successfully uploaded new clients into the FIKA database", 'success')
        return render_template("user.html")

    else:
        flash("You don't have privilege to upload new members to the FIKA database, Action reported to the admin",
              'danger')
        return render_template("user.html")

@app.route("/home")
def home():
    if session['username'] == "pandaXmin":
        return render_template("admin.html",message="Hi please have a look at alerts & Notifications for you -->")
    else:
        return redirect(url_for('login',username=session['username']))

@app.route("/add_member",methods=['GET', 'POST'])
def add_member():
    if request.method == 'POST':
        isMemberAddedd = add_new_member_to_fika(request.form)
        if isMemberAddedd:
            flash("Successfully added new client " + str(request.form['name']) + " to the FIKA database" , 'success')
        else:
            flash("This User id is already taken , please try with new Identification Number",
                  'danger')
    return render_template("add_member.html")

@app.route("/client_details")
def client_details():
    client_db = get_client_details()
    return render_template("client_details.html", column_names=client_db.columns.values, row_data=list(client_db.values.tolist()),
                           link_column="id", zip=zip)

@app.route("/client_ind_page",methods=['GET','POST'])
def ind_client_page():
    client_id = request.form['person_id']
    print(client_id)
    global client_df
    ind_client_data = client_df.loc[client_df['id'] == client_id]
    print(ind_client_data.to_dict('r'))
    return render_template("ind_client_page.html",ind_client_data=ind_client_data)